#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(int argc, char **argv) {

  int fd, err;

  char *sample1 = " Open() for reading only will return without delay. \
  An open() for writing only will return an error \
  if no process currently has the file open for reading. If O_NONBLOCK is set, \
  the open() function will return without blocking for the device to be ready \
  or available. Subsequent behaviour of the device is device-specific.";

  char *sample2 = "Error!!! Should not appper!";

  fd = open("/dev/serp", O_RDWR | O_NONBLOCK);

  if (fd < 0) {
    printf("Error opening file discriptor!\n");
    return -EBADF;
  }

  printf("Testing O_NONBLOCK flag - \n\n");

  if((err = write(fd, sample1, strlen(sample1))) < 0){
      perror("Error - ");
  }
  if((err = write(fd, sample2, strlen(sample2))) < 0){
      perror("Error - ");
  }

  close(fd);

  return 0;
}
