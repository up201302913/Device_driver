
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>

#include <linux/interrupt.h>
#include <linux/kfifo.h>

#include <linux/kernel.h>	/* printk() */
#include <linux/slab.h>		/* kmalloc() */
#include <linux/fs.h>		/* everything... */
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>	/* O_ACCMODE */
#include <linux/aio.h>
#include <linux/cdev.h>  /* cdev*/
#include <linux/delay.h>
#include <linux/jiffies.h>
#include <linux/sched.h>
#include <linux/ioport.h>
#include <linux/wait.h>

#include <asm/uaccess.h>
#include <asm/io.h>

#include "serial_reg.h"
#include "serp.h"

MODULE_LICENSE("Dual BSD/GPL");


int serp_major = SERP_MAJOR;
int serp_minor = SERP_MINOR;

int major = 0, minor = 0;

struct serp_devs *serp_devices = NULL;

dev_t dev;

irqreturn_t short_interrupt(int irq, void *dev_id){

  struct serp_devs *vdev = (struct serp_devs *) dev_id;
  char buffer;
  unsigned char IIR_ADDR;

  //printk(KERN_INFO "\nIRQ HANDLER START\n");

  IIR_ADDR = inb(ADR_COM1+UART_IIR);

  //HANDLER WRITE
  if(IIR_ADDR & UART_IIR_THRI){ //Data transmission ready
    if(kfifo_len(vdev->txbuf)) {
      if(kfifo_get(vdev->txbuf, &buffer, 1) != 0) {
        //printk(KERN_INFO "FIFO RX receiving sucess!");
        outb(buffer, ADR_COM1 + UART_TX);
        wake_up_interruptible(&(vdev->txwait));
      }
    }
  // HANDLER READ
  } else if(IIR_ADDR & UART_IIR_RDI){ //Data received ready
      buffer = inb(ADR_COM1 + UART_RX);
      kfifo_put(vdev->rxbuf, &buffer, 1);
      wake_up_interruptible(&(vdev->rxwait));
  }

  //printk(KERN_INFO "\nIRQ HANDLER END\n");
  return IRQ_HANDLED; //tava assim no livro

}

int serp_open(struct inode *inode, struct file *filep){

  struct serp_devs *sdev;

  printk(KERN_NOTICE "Device driver on serp_open function!\n");

  sdev = container_of(inode->i_cdev,struct serp_devs, serp_cdevs);
  filep->private_data = sdev;

  if(filep->private_data == NULL)
      printk(KERN_WARNING "Private data not initialized correctly!\n");

  nonseekable_open(inode, filep); //Non-seekable DD

  spin_lock(&sdev->user_Control.lock);

  // Check number of users, user uid, user euid (su user) and compare to current user, except for the super root user that can bypass security
  if(sdev->user_Control.count && (sdev->user_Control.uid != current->uid) && (sdev->user_Control.uid != current->euid) && !capable(CAP_DAC_OVERRIDE)){
      spin_unlock(&sdev->user_Control.lock);
      return -EBUSY; // Busy error instead of not permited!
  } else if (sdev->user_Control.count){
      spin_unlock(&sdev->user_Control.lock);
      return -EBUSY; // Busy error instead of not permited!
  }
  if(sdev->user_Control.count == 0){ // If no cuurent user, the control struct gets the current user id
      sdev->user_Control.uid = current->uid;
  }

  sdev->user_Control.count++;

  //printk("%d\n",sdev->user_Control.count);

  spin_unlock(&sdev->user_Control.lock);

  if(filep->f_flags & O_NONBLOCK) {
      sdev->o_nonblock_flag = 1;
  } else {
      sdev->o_nonblock_flag = 0;
  }

  printk(KERN_NOTICE "Device driver successfully open!\n");

  return 0;

}

int serp_release(struct inode *inode,struct file *filep){

  struct serp_devs *sdev;
  sdev = filep->private_data;

  spin_lock(&sdev->user_Control.lock);

  sdev->user_Control.count--;

  spin_unlock(&sdev->user_Control.lock);


  printk(KERN_WARNING "\n\nDevice driver released!\n\n");

  return 0;

}

int serp_flush(struct inode *inode,fl_owner_t id){

  printk(KERN_WARNING "Driver flushed!\n");

  return 0;
}

ssize_t serp_read(struct file *filep, char __user *buff, size_t count, loff_t *offp) {


  int sinal = 1;
  int c, f_lenght;
  unsigned long result;

  char *kernelbuffer;

  struct serp_devs *devp;
  devp = filep->private_data;

  if(count > SIZE_FIFO){
    printk(KERN_WARNING "SIZE REQUESTED LARGER THAN SIZE OF BUFFER!");
    return -EMSGSIZE;
  }

  kernelbuffer = (char *)kmalloc((count+1)*sizeof(char), GFP_KERNEL);

  if(!kernelbuffer){
    return -ENOMEM;
  }

  //printk(KERN_INFO "READ FUNCTION\n");

  while((f_lenght = kfifo_len(devp->rxbuf)) < count){

    if(devp->o_nonblock_flag == 1){
        if(kfifo_len(devp->rxbuf) == 0){
            kfree(kernelbuffer);
            return -EWOULDBLOCK;
        }
    }
    sinal = wait_event_interruptible_timeout(devp->rxwait,((kfifo_len(devp->rxbuf))>f_lenght),TIMEOUT);

    if(sinal==0){
       break;
    }
    if(sinal==-ERESTARTSYS){
      kfree(kernelbuffer);
      return -ERESTARTSYS;
    }
  }

  if(sinal == 0)
    c = kfifo_len(devp->rxbuf);
  else{
    c = count;
    kernelbuffer[c] = '\0';
  }
  //printk(KERN_INFO "KFIFO_GET\n");

  if(kfifo_get(devp->rxbuf,kernelbuffer,c) != c){
    printk(KERN_ALERT "KFIFO_GET ERROR\n");
		kfree(kernelbuffer);
		return -1;
  }

  result = copy_to_user(buff, kernelbuffer, c);

  if(result == 0) {
    printk(KERN_INFO "\nCharacters received: %d\n", c);
  } else{
    if(result > 0) {
      printk(KERN_INFO "Missing %d characters!\n", count);
      return -EIO;
    }
  }

  kfree(kernelbuffer);
  return c;

}

ssize_t serp_write(struct file *filep, const char __user *buff, size_t count, loff_t *offp) {

  int i=0;
	unsigned long result;
  int buffer_sent = 0, buffer_left = count;
  char ch;
  char *kernelbuffer;

  struct serp_devs *devp;
  devp = filep->private_data;

	kernelbuffer = (char *) kzalloc(sizeof(char)*(count+1), GFP_KERNEL);

	if(kernelbuffer == NULL) {
	     printk(KERN_ALERT "Error allocating memory for kernel buffer space!\n");
		   return -ENOMEM;
	}

	result = copy_from_user(kernelbuffer, buff, count);

	if(result == 0){
      printk(KERN_INFO "Copy from user kernel successful!\n");

	} else if(result>0){
      printk(KERN_INFO "Error in coping from user kernel! Result: %ld\n", result);
	    return -EFAULT;
	}

	kernelbuffer[count]='\0';

  while(1){

    if(devp->o_nonblock_flag == 1){
        if(kfifo_len(devp->txbuf) == SIZE_FIFO){
            kfree(kernelbuffer);
            return -EWOULDBLOCK;
        }
    }
    if(wait_event_interruptible(devp->txwait, (kfifo_len(devp->txbuf) < SIZE_FIFO)) ==-ERESTARTSYS){
        kfree(kernelbuffer);
        return -EINTR;
    }
    buffer_sent = kfifo_put(devp->txbuf, kernelbuffer, buffer_left);
    buffer_left -= buffer_sent;
    if(buffer_left != 0){
      for(i=0; kernelbuffer[i+buffer_sent] != '\0'; i++)
          kernelbuffer[i] = kernelbuffer[i+buffer_sent];
          kernelbuffer[i] = '\0';
    }
    if((inb(ADR_COM1 + UART_LSR) & UART_LSR_THRE)) {
        if(kfifo_get(devp->txbuf, &ch, 1) != 0) {
          outb(ch, ADR_COM1 + UART_TX);
        }
    }
    if(buffer_left<=0)
      break;
  }

	kfree(kernelbuffer);

	return count;
}

struct file_operations serp_fops = {
  .owner =      THIS_MODULE,
  .open =       serp_open,
  .release =    serp_release,
  .write  =     serp_write,
  .read   =     serp_read,
  .llseek =     no_llseek,
//  .flush  =     serp_flush,
};

/*
static void serp_setup(struct serp_devs *dev, int index ){

  int err;
  int devno = MKDEV(major, minor + index);


  cdev_init(&dev->serp_cdevs, &serp_fops);
  dev->serp_cdevs.owner = THIS_MODULE;
  dev->serp_cdevs.ops = &serp_fops;

  err = cdev_add(&dev->serp_cdevs, devno, 1);

  if (err < 0) {
    printk(KERN_INFO "Error %d at adding serp_cdevs %d!\n", err, index);
  } else {
		printk(KERN_INFO "Device major %d with minor %d added successful!\n ", major, index);
  }

}
*/
static int serp_init(void) {

	int result;
  unsigned char lcr = 0,ier = 0, fifo = 0;


    int err;

	// Register your major, and accept a dynamic number.

	if (serp_major){
    dev = MKDEV(serp_major,serp_minor);
		result = register_chrdev_region(dev, serp_minor, "serp");
  }
	else {
		result = alloc_chrdev_region(&dev, 0, serp_minor, "serp");
		major = MAJOR(dev);
    minor = MINOR(dev);
    printk(KERN_ALERT "Major allocated : %d\n", major);
    printk(KERN_ALERT "Minor allocated : %d\n", minor);
  }
  if(result < 0){
    printk(KERN_WARNING "Error in allocating major device!");
    return result;
  }


  serp_devices = kmalloc(sizeof(struct serp_devs), GFP_KERNEL);

  if(serp_devices == NULL){
    printk(KERN_ALERT "Failed to allocated serp devices!\n");
    return -ENOMEM;
  }

  cdev_init(&serp_devices->serp_cdevs, &serp_fops);
  serp_devices->serp_cdevs.owner = THIS_MODULE;
  serp_devices->serp_cdevs.ops = &serp_fops;

  spin_lock_init(&serp_devices->rxlock);
  spin_lock_init(&serp_devices->txlock);

  serp_devices->rxbuf = kfifo_alloc(SIZE_FIFO,GFP_KERNEL,&(serp_devices->rxlock));
  serp_devices->txbuf = kfifo_alloc(SIZE_FIFO, GFP_KERNEL,&(serp_devices->txlock));

  init_waitqueue_head(&serp_devices->rxwait);
  init_waitqueue_head(&serp_devices->txwait);

  err = cdev_add(&serp_devices->serp_cdevs, dev, 1);

  if (err < 0) {
    printk(KERN_INFO "Error %d at adding serp_cdevs!\n", err);
  } else {
    printk(KERN_INFO "Device major %d with minor %d added successful!\n ", major, minor);
  }


  	printk(KERN_NOTICE "MAJOR NUMBER: %d\n",major);


  //request_region
  if (request_region(ADR_COM1, 8, "serp")) {
      printk(KERN_INFO "Serial port I/O port range reserved successful!\n");
  } else {
      printk(KERN_ALERT "Serial port I/O requested already in use!\n");
      return -EREMOTEIO;
  }

  // UART communication parameters: 8-bit chars, 2 stop bits, parity even, and 1200 bps with no interrupts

  // UART 8bit chars / 2 stop bits / Parity even / No interrupts
  lcr = UART_LCR_WLEN8 | UART_LCR_PARITY | UART_LCR_EPAR | UART_LCR_STOP;
  outb(lcr, ADR_COM1 + UART_LCR);

  // Divisor Latch access
  lcr |= UART_LCR_DLAB;
  outb(lcr, ADR_COM1 + UART_LCR);

  //Bitrate 1200 bps
  outb(UART_DIV_1200, ADR_COM1+UART_DLL);
  outb(0x00, ADR_COM1+UART_DLM);

  //Divisor Lacth end, reset the DLAB so that the other registers can be accessed
  lcr &= ~UART_LCR_DLAB;
  outb(lcr, ADR_COM1+UART_LCR);

  //ier = inb(ADR_COM1+UART_IER);
  ier |= UART_IER_RDI | UART_IER_THRI |UART_IER_RLSI;
  outb(ier,ADR_COM1+UART_IER);

  fifo |= UART_FCR_ENABLE_FIFO | UART_FCR_TRIGGER_MASK;
  outb(fifo, ADR_COM1+UART_FCR);

  if(request_irq(IRQ_NUM, short_interrupt ,SA_INTERRUPT, "serp", (void*) serp_devices) != 0){
      printk(KERN_ALERT "ERRO no REQUEST IRQ");
      return -ERESTART;
  }

  return result;
}



static void serp_exit(void) {

  //printk(KERN_ALERT "Fairwell major %d\n",serp_major);
  kfifo_free(serp_devices->rxbuf);
  kfifo_free(serp_devices->txbuf);

  free_irq(IRQ_NUM, (void*) serp_devices);

  if (serp_devices) {
      cdev_del(&serp_devices->serp_cdevs);
  }

  unregister_chrdev_region(MKDEV(major,0), serp_minor);

  // Release previous allocated region with address from (0x3f8-0x3ff)
  release_region(ADR_COM1, 8);

  kfree(serp_devices);

  printk(KERN_ALERT "Device driver with Major number %d was deleted!\n", major);

}

module_init(serp_init);
module_exit(serp_exit);
